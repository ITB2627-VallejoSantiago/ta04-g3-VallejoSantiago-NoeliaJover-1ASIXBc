# -*- coding: utf-8 -*-
"""
===============================================================================
CYBER-CORE v5.2 // OBSERVATORI WEB PRO [ABSOLUTE CINEMA EDITION]
Assignatura: MDS / 0373 Llenguatge de Marques - TA04
Autors: Santiago Vallejo & Noelia Jover (Grup 3) - ASIXc1B, ITB Barcelona
===============================================================================
Servidor HTTP local lleuger i Panell Web d'Alta Fidelitat amb temes Cyberpunk,
telemetria en temps real, radar animat i compliment estricte de la Rúbrica F1-F5.
"""

import json
import os
import sys
import threading
import webbrowser
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from analitzar_incidencies import CAMPS, netejar, validar_registres, exportar_json

CARPETA = Path(__file__).resolve().parent

HTML = r'''<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CYBER-CORE v5.2 // Observatori Web d'Incidències [ASIXc1B]</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #070913;
      --panel: #0d1322;
      --panel-hover: #131c31;
      --header-bg: #111a2e;
      --border: #1e2c47;
      --border-glow: #00f2fe33;
      --text: #f1f5f9;
      --muted: #8fa0bc;
      --cyan: #00f2fe;
      --purple: #a855f7;
      --pink: #ec4899;
      --green: #10b981;
      --red: #f43f5e;
      --amber: #f59e0b;
      --font-main: 'Outfit', system-ui, sans-serif;
      --font-mono: 'JetBrains Mono', Consolas, monospace;
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-main);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
      background-image: 
        radial-gradient(circle at 15% 15%, rgba(0, 242, 254, 0.05) 0%, transparent 40%),
        radial-gradient(circle at 85% 85%, rgba(168, 85, 247, 0.05) 0%, transparent 40%);
    }

    /* TOP BAR */
    header {
      background: rgba(13, 19, 34, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border);
      padding: 14px 28px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-group {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .logo-badge {
      background: linear-gradient(135deg, #00f2fe, #a855f7);
      width: 44px;
      height: 44px;
      border-radius: 12px;
      display: grid;
      place-items: center;
      font-size: 22px;
      font-weight: 800;
      box-shadow: 0 0 20px rgba(0, 242, 254, 0.4);
    }

    .brand-text h1 {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: -0.5px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .brand-text h1 .version {
      background: rgba(0, 242, 254, 0.12);
      color: var(--cyan);
      font-size: 11px;
      font-family: var(--font-mono);
      padding: 2px 8px;
      border-radius: 20px;
      border: 1px solid rgba(0, 242, 254, 0.3);
    }

    .brand-text p {
      font-size: 11px;
      color: var(--muted);
      font-weight: 500;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .live-clock {
      font-family: var(--font-mono);
      font-size: 13px;
      color: var(--cyan);
      background: var(--header-bg);
      padding: 7px 14px;
      border-radius: 8px;
      border: 1px solid var(--border);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .pulse-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--green);
      box-shadow: 0 0 10px var(--green);
      animation: pulse 1.5s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(0.85); }
    }

    button.btn {
      font-family: var(--font-main);
      font-size: 12px;
      font-weight: 700;
      border: 0;
      border-radius: 8px;
      padding: 8px 16px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 7px;
      transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .btn:hover { transform: translateY(-2px); }
    .btn-cyan { background: var(--cyan); color: #060913; box-shadow: 0 0 15px rgba(0, 242, 254, 0.3); }
    .btn-purple { background: var(--purple); color: #fff; box-shadow: 0 0 15px rgba(168, 85, 247, 0.3); }
    .btn-dark { background: var(--header-bg); color: var(--text); border: 1px solid var(--border); }
    .btn-dark:hover { border-color: var(--cyan); color: var(--cyan); }

    /* LAYOUT */
    .app-container {
      max-width: 1680px;
      margin: 0 auto;
      padding: 24px 28px;
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    /* HUD METRICS */
    .hud-grid {
      display: grid;
      grid-template-columns: 240px 1fr 1fr 1fr 1fr;
      gap: 16px;
    }

    .hud-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 16px 20px;
      position: relative;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 0.25s;
    }

    .hud-card:hover {
      border-color: var(--cyan);
      box-shadow: 0 8px 25px rgba(0, 242, 254, 0.1);
    }

    .hud-card::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
    }
    .hud-card.purple::after { background: var(--purple); }
    .hud-card.green::after { background: var(--green); }
    .hud-card.red::after { background: var(--red); }
    .hud-card.cyan::after { background: var(--cyan); }

    .hud-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .hud-value {
      font-size: 32px;
      font-weight: 800;
      font-family: var(--font-mono);
      margin: 6px 0 2px;
    }
    .hud-card.purple .hud-value { color: var(--purple); }
    .hud-card.green .hud-value { color: var(--green); }
    .hud-card.red .hud-value { color: var(--red); }
    .hud-card.cyan .hud-value { color: var(--cyan); }

    .hud-sub {
      font-size: 11px;
      color: var(--muted);
    }

    /* RADAR MINI WIDGET */
    .radar-container {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 12px;
      display: flex;
      align-items: center;
      gap: 14px;
    }
    canvas#radar {
      background: var(--header-bg);
      border-radius: 50%;
      border: 1px solid var(--border);
    }
    .radar-info h3 { font-size: 12px; font-weight: 700; color: var(--cyan); }
    .radar-info p { font-size: 10px; color: var(--muted); font-family: var(--font-mono); }

    /* NAV TABS */
    .nav-bar {
      display: flex;
      gap: 8px;
      border-bottom: 1px solid var(--border);
      padding-bottom: 12px;
    }

    .tab-btn {
      background: var(--panel);
      color: var(--muted);
      border: 1px solid var(--border);
      padding: 10px 20px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s;
    }

    .tab-btn:hover {
      color: var(--text);
      background: var(--panel-hover);
    }

    .tab-btn.active {
      background: var(--header-bg);
      color: var(--cyan);
      border-color: var(--cyan);
      box-shadow: 0 0 15px rgba(0, 242, 254, 0.15);
    }

    /* TAB CONTENT PANELS */
    .tab-content { display: none; }
    .tab-content.active { display: block; }

    /* FILTERS BAR */
    .filter-panel {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 16px 20px;
      display: flex;
      flex-wrap: wrap;
      gap: 14px;
      align-items: flex-end;
    }

    .filter-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex: 1;
      min-width: 170px;
    }

    .filter-group.search-group { flex: 2; min-width: 250px; }

    .filter-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    input.input-field, select.input-field {
      background: var(--header-bg);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 10px 14px;
      color: var(--text);
      font-family: var(--font-main);
      font-size: 13px;
      width: 100%;
      outline: none;
      transition: border 0.2s;
    }

    input.input-field:focus, select.input-field:focus {
      border-color: var(--cyan);
      box-shadow: 0 0 10px rgba(0, 242, 254, 0.2);
    }

    /* DATA TABLE */
    .table-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      overflow: hidden;
      margin-top: 14px;
    }

    .table-responsive {
      max-height: 540px;
      overflow-y: auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 13px;
    }

    th {
      background: var(--header-bg);
      color: var(--cyan);
      font-weight: 700;
      padding: 12px 16px;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      position: sticky;
      top: 0;
      z-index: 10;
      border-bottom: 1px solid var(--border);
    }

    td {
      padding: 12px 16px;
      border-bottom: 1px solid rgba(30, 44, 71, 0.4);
      color: var(--text);
    }

    tr:hover td {
      background: var(--panel-hover);
      cursor: pointer;
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      font-family: var(--font-mono);
    }
    .badge-red { background: rgba(244, 63, 94, 0.15); color: var(--red); border: 1px solid rgba(244, 63, 94, 0.3); }
    .badge-amber { background: rgba(245, 158, 11, 0.15); color: var(--amber); border: 1px solid rgba(245, 158, 11, 0.3); }
    .badge-green { background: rgba(16, 185, 129, 0.15); color: var(--green); border: 1px solid rgba(16, 185, 129, 0.3); }
    .badge-cyan { background: rgba(0, 242, 254, 0.15); color: var(--cyan); border: 1px solid rgba(0, 242, 254, 0.3); }

    /* MODAL FORENSE */
    .modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(4, 6, 14, 0.85);
      backdrop-filter: blur(8px);
      display: none;
      place-items: center;
      z-index: 1000;
      padding: 20px;
    }
    .modal-overlay.open { display: grid; }

    .modal-card {
      background: var(--panel);
      border: 1px solid var(--cyan);
      box-shadow: 0 0 40px rgba(0, 242, 254, 0.2);
      border-radius: 18px;
      max-width: 720px;
      width: 100%;
      overflow: hidden;
      animation: modalIn 0.25s ease-out;
    }

    @keyframes modalIn {
      from { transform: scale(0.92); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }

    .modal-header {
      background: var(--header-bg);
      padding: 18px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid var(--border);
    }
    .modal-header h2 { font-size: 16px; font-weight: 800; color: var(--cyan); }
    .close-btn { background: none; border: 0; color: var(--muted); font-size: 20px; cursor: pointer; }
    .close-btn:hover { color: #fff; }

    .modal-body {
      padding: 24px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 13px;
    }

    .dossier-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      background: var(--header-bg);
      padding: 16px;
      border-radius: 10px;
      border: 1px solid var(--border);
    }
    .dossier-item .k { font-size: 11px; color: var(--muted); font-weight: 700; text-transform: uppercase; }
    .dossier-item .v { font-size: 13px; font-weight: 600; color: var(--text); margin-top: 2px; }

    .problem-box {
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 14px;
      font-family: var(--font-mono);
      font-size: 12px;
      line-height: 1.6;
    }

    /* TELEMETRY CARDS */
    .telemetry-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    .stat-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 20px;
    }

    .stat-card h3 {
      font-size: 14px;
      font-weight: 800;
      color: var(--cyan);
      margin-bottom: 14px;
      display: flex;
      justify-content: space-between;
    }

    .bar-row {
      margin-bottom: 12px;
    }
    .bar-header {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      font-weight: 600;
      margin-bottom: 4px;
    }
    .bar-track {
      background: var(--header-bg);
      height: 10px;
      border-radius: 6px;
      overflow: hidden;
      border: 1px solid var(--border);
    }
    .bar-fill {
      height: 100%;
      border-radius: 6px;
      transition: width 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    /* TIMER DE PRESENTACIO */
    .timer-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 30px;
      text-align: center;
      max-width: 800px;
      margin: 0 auto;
    }
    .timer-digits {
      font-size: 80px;
      font-weight: 800;
      font-family: var(--font-mono);
      color: var(--green);
      text-shadow: 0 0 30px rgba(16, 185, 129, 0.3);
      margin: 15px 0;
    }

    /* JSON CODE VIEWER */
    pre.code-view {
      background: #04060c;
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 16px;
      font-family: var(--font-mono);
      font-size: 12px;
      max-height: 480px;
      overflow: auto;
      color: #7dd3fc;
    }
  </style>
</head>
<body>

  <!-- HEADER -->
  <header>
    <div class="brand-group">
      <div class="logo-badge">⚡</div>
      <div class="brand-text">
        <h1>CYBER-CORE <span class="version">v5.2 WEB PRO</span></h1>
        <p>OBSERVATORI FORENSE // MDS TA04 • GRUP 3 (ASIXc1B)</p>
      </div>
    </div>

    <div class="header-actions">
      <div class="live-clock">
        <span class="pulse-dot"></span>
        <span id="clock">--:--:--</span>
      </div>
      <button class="btn btn-dark" onclick="carregarLocal()">🔄 Recarregar XML</button>
      <button class="btn btn-purple" onclick="exportarJSON()">💾 Exportar JSON (F4)</button>
      <button class="btn btn-cyan" onclick="setTab('presentacio')">⏱️ Cronòmetre (4m)</button>
    </div>
  </header>

  <!-- MAIN APP CONTAINER -->
  <div class="app-container">

    <!-- HUD STATS -->
    <div class="hud-grid">
      <!-- RADAR WIDGET -->
      <div class="radar-container">
        <canvas id="radar" width="60" height="60"></canvas>
        <div class="radar-info">
          <h3>SEC-OPS</h3>
          <p id="radar-status">SCANNING...</p>
        </div>
      </div>

      <div class="hud-card purple">
        <div class="hud-label">Total Escanejades</div>
        <div class="hud-value" id="kpi-total">4,407</div>
        <div class="hud-sub">Registres CSV/XML</div>
      </div>

      <div class="hud-card green">
        <div class="hud-label">Acceptades / Vàlides</div>
        <div class="hud-value" id="kpi-accepted">4,054</div>
        <div class="hud-sub">Depurades i Nominals</div>
      </div>

      <div class="hud-card red">
        <div class="hud-label">Descartades / Brossa</div>
        <div class="hud-value" id="kpi-rejected">353</div>
        <div class="hud-sub">Anomalies / Duplicats / 2064</div>
      </div>

      <div class="hud-card cyan">
        <div class="hud-label">Ràtio d'Integritat</div>
        <div class="hud-value" id="kpi-quality">92.0%</div>
        <div class="hud-sub">Qualitat de Dades</div>
      </div>
    </div>

    <!-- TABS NAVIGATION -->
    <div class="nav-bar">
      <button class="tab-btn active" onclick="setTab('radar')">🛰️ Radar d'Incidències</button>
      <button class="tab-btn" onclick="setTab('telemetria')">📊 Telemetria & Gràfics</button>
      <button class="tab-btn" onclick="setTab('forense')">☣️ Filtre Forense (353 Descartades)</button>
      <button class="tab-btn" onclick="setTab('json')">💾 Gestor JSON (F4)</button>
      <button class="tab-btn" onclick="setTab('presentacio')">⏱️ Cronòmetre</button>
      <button class="tab-btn" onclick="setTab('teoria')">🧠 Teoria: Dades vs Info</button>
    </div>

    <!-- TAB 1: RADAR & GRAELLA -->
    <div id="tab-radar" class="tab-content active">
      <div class="filter-panel">
        <div class="filter-group search-group">
          <label class="filter-label">🔍 Cerca Global</label>
          <input type="text" id="searchInput" class="input-field" placeholder="Cerca per nom, departament, equip, categoria..." oninput="filtrarTaula()">
        </div>

        <div class="filter-group">
          <label class="filter-label">Departament</label>
          <select id="filtre-dept" class="input-field" onchange="filtrarTaula()"><option value="">Tots</option></select>
        </div>

        <div class="filter-group">
          <label class="filter-label">Categoria</label>
          <select id="filtre-cat" class="input-field" onchange="filtrarTaula()"><option value="">Totes</option></select>
        </div>

        <div class="filter-group">
          <label class="filter-label">Dispositiu</label>
          <select id="filtre-disp" class="input-field" onchange="filtrarTaula()"><option value="">Tots</option></select>
        </div>

        <div class="filter-group">
          <label class="filter-label">Impacte</label>
          <select id="filtre-imp" class="input-field" onchange="filtrarTaula()"><option value="">Tots</option></select>
        </div>

        <button class="btn btn-dark" style="height: 42px;" onclick="netejarFiltres()">✕ Netejar</button>
      </div>

      <div class="table-card">
        <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th>Data i Hora</th>
                <th>Usuari</th>
                <th>Departament</th>
                <th>Dispositiu</th>
                <th>Equip</th>
                <th>Categoria</th>
                <th>Impacte</th>
              </tr>
            </thead>
            <tbody id="taula-body">
              <tr><td colspan="7" style="text-align:center; padding: 40px; color: var(--muted);">Carregant registres forenses...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- TAB 2: TELEMETRIA & GRAFICS -->
    <div id="tab-telemetria" class="tab-content">
      <div class="telemetry-grid">
        <div class="stat-card">
          <h3>DISTRIBUCIÓ PER CATEGORIA <span>5 Categories</span></h3>
          <div id="stats-categoria"></div>
        </div>

        <div class="stat-card">
          <h3>IMPACTE SOBRE EL TREBALL <span>Grau de Bloqueig</span></h3>
          <div id="stats-impacte"></div>
        </div>

        <div class="stat-card">
          <h3>DISTRIBUCIÓ PER DISPOSITIU <span>Hardware</span></h3>
          <div id="stats-dispositiu"></div>
        </div>

        <div class="stat-card">
          <h3>ABAST D'AFECTACIÓ <span>Usuaris Afectats</span></h3>
          <div id="stats-abast"></div>
        </div>
      </div>
    </div>

    <!-- TAB 3: FILTRE FORENSE (DESCARTADES) -->
    <div id="tab-forense" class="tab-content">
      <div class="table-card">
        <div style="padding: 16px 20px; background: var(--header-bg); border-bottom: 1px solid var(--border);">
          <h3 style="color: var(--red); font-size: 14px;">REGISTRES DESCARTATS AUTOMÀTICAMENT (353 ANOMALIES)</h3>
          <p style="color: var(--muted); font-size: 12px; margin-top: 4px;">Aquests registres contenen anomalies temporals (ex: any 2064), descripcions menors de 15 caràcters, frases genèriques com "no funciona" o registres duplicats exactes.</p>
        </div>
        <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th>Registre #</th>
                <th>Motiu de la Descàrrega</th>
                <th>Nom Usuari</th>
                <th>Data Registrada</th>
                <th>Descripció Detectada</th>
              </tr>
            </thead>
            <tbody id="taula-descartades">
              <!-- Renderitzat via JS -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- TAB 4: GESTOR JSON (REQUISIT F4) -->
    <div id="tab-json" class="tab-content">
      <div class="stat-card" style="margin-bottom: 16px;">
        <h3>REQUISIT F4: PERSISTÈNCIA EN incidencies.json</h3>
        <p style="color: var(--muted); font-size: 13px; margin: 6px 0 16px;">El sistema comprova si el fitxer ja existeix abans d'escriure. Pots sobreescriure'l o afegir noves incidències comprovant IDs per evitar duplicats.</p>
        <div style="display:flex; gap: 10px;">
          <button class="btn btn-cyan" onclick="exportarJSON('overwrite')">⚡ Sobreescriure JSON</button>
          <button class="btn btn-purple" onclick="exportarJSON('append')">➕ Afegir sense Duplicats per ID</button>
          <a class="btn btn-dark" href="/api/download_json" download="incidencies.json">📥 Descarregar Fitxer incidencies.json</a>
        </div>
      </div>

      <pre class="code-view" id="json-viewer">// Carregant preview de incidencies.json...</pre>
    </div>

    <!-- TAB 5: CRONÒMETRE DE PRESENTACIÓ -->
    <div id="tab-presentacio" class="tab-content">
      <div class="timer-card">
        <h2 style="color: var(--cyan); font-size: 20px;">⏱️ CRONÒMETRE DE CONTROL DE TEMPS</h2>
        <p style="color: var(--muted); font-size: 13px; margin-top: 6px;">Temporitzador de compte enrere per a la presentació del projecte.</p>
        
        <div class="timer-digits" id="timer-display">04:00</div>

        <div style="display: flex; justify-content: center; gap: 12px;">
          <button class="btn btn-cyan" style="font-size: 14px; padding: 10px 22px;" id="btn-timer" onclick="toggleTimer()">▶ INICIAR CRONÒMETRE</button>
          <button class="btn btn-dark" style="font-size: 14px; padding: 10px 22px;" onclick="resetTimer()">🔄 REINICIAR (04:00)</button>
        </div>
      </div>
    </div>

    <!-- TAB 6: TEORIA (DADES VS INFO) -->
    <div id="tab-teoria" class="tab-content">
      <div class="stat-card" style="line-height: 1.8;">
        <h2 style="color: var(--cyan); font-size: 18px; margin-bottom: 12px;">🧠 TEORIA: DADES CRUES VS INFORMACIÓ ÚTIL (RÚBRICA F3)</h2>
        
        <h4 style="color: var(--purple); margin-top: 10px;">1. Quina és la diferència entre dades i informació?</h4>
        <p style="color: var(--text);">• <strong>Dada (Data):</strong> Valors individuals sense processar ni context. Ex: 'PC-67', '2026-11-03', 'Perifèrics'. No permeten prendre decisions per si soles.</p>
        <p style="color: var(--text);">• <strong>Informació:</strong> Dades estructurades, validades i contextualitzades. Ex: 'El 58.8% d'incidències afecten portàtils, amb un 65.3% de bloqueig parcial'. Aporta intel·ligència per a decisions de negoci i ciberseguretat.</p>

        <h4 style="color: var(--purple); margin-top: 14px;">2. Per què és imprescindible filtrar registres com els de l'any 2064?</h4>
        <p style="color: var(--text);">Si s'alimenta un sistema de gestió amb dades errònies, duplicades o incoherents temporalment, les estadístiques queden desvirtuades (Principi GIGO: <em>Garbage In, Garbage Out</em>). El filtre forense neteja 353 registres abans del càlcul.</p>

        <h4 style="color: var(--purple); margin-top: 14px;">3. RGPD i per què no es pot utilitzar IA externa:</h4>
        <p style="color: var(--text);">El RGPD impedeix enviar dades personals d'usuaris (noms, ubicacions, comptes) a models d'IA comercials al núvol sense garanties ni consentiment exprés. Tot el nostre algoritme s'executa 100% en local.</p>
      </div>
    </div>

  </div>

  <!-- MODAL FORENSE DETALL -->
  <div id="modal" class="modal-overlay" onclick="closeModal(event)">
    <div class="modal-card" onclick="event.stopPropagation()">
      <div class="modal-header">
        <h2>📋 DOSSIER FORENSE D'INCIDÈNCIA</h2>
        <button class="close-btn" onclick="closeModal()">✕</button>
      </div>
      <div class="modal-body" id="modal-content">
        <!-- Contingut generat dinàmicament -->
      </div>
    </div>
  </div>

  <script>
    // RELOGE EN TEMPS REAL
    setInterval(() => {
      document.getElementById('clock').innerText = new Date().toLocaleTimeString('ca-ES');
    }, 1000);

    // RADAR CANVAS ANIMATION
    const radar = document.getElementById('radar');
    const ctx = radar.getContext('2d');
    let angle = 0;
    function drawRadar() {
      ctx.clearRect(0, 0, 60, 60);
      const cx = 30, cy = 30, r = 26;
      ctx.strokeStyle = '#1e2c47';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, cy, r*0.6, 0, Math.PI*2); ctx.stroke();
      
      const rad = angle * Math.PI / 180;
      ctx.strokeStyle = '#00f2fe';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + r * Math.cos(rad), cy + r * Math.sin(rad));
      ctx.stroke();

      angle = (angle + 6) % 360;
      requestAnimationFrame(drawRadar);
    }
    drawRadar();

    // DADES GLOBALS
    let dataset = [];
    let rejected = [];
    let groups = {};

    // CARREGA INICIAL AUTOMÀTICA
    async function carregarLocal() {
      try {
        const res = await fetch('/api/data');
        const data = await res.json();
        dataset = data.accepted || [];
        rejected = data.rejected || [];
        groups = data.groups || {};

        document.getElementById('kpi-total').innerText = (data.total || 4407).toLocaleString();
        document.getElementById('kpi-accepted').innerText = dataset.length.toLocaleString();
        document.getElementById('kpi-rejected').innerText = rejected.length.toLocaleString();
        const pct = (dataset.length / (data.total || 4407) * 100).toFixed(1);
        document.getElementById('kpi-quality').innerText = pct + '%';
        document.getElementById('radar-status').innerText = dataset.length + ' ACTIVE';

        poblarFiltres();
        renderTaula(dataset);
        renderTelemetria();
        renderDescartades();
        renderJSONPreview();
      } catch (e) {
        console.error("Error carregant dades:", e);
      }
    }
    carregarLocal();

    // PESTANYES
    function setTab(name) {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      event.target.classList.add('active');
      document.getElementById('tab-' + name).classList.add('active');
    }

    // POBLAR FILTRES DESPLEGABLES
    function poblarFiltres() {
      poblarSelect('filtre-dept', 'departament');
      poblarSelect('filtre-cat', 'categoria');
      poblarSelect('filtre-disp', 'dispositiu');
      poblarSelect('filtre-imp', 'impacte');
    }

    function poblarSelect(id, field) {
      const select = document.getElementById(id);
      const valors = [...new Set(dataset.map(r => r.fields[field]).filter(Boolean))].sort();
      select.innerHTML = '<option value="">Tots</option>' + valors.map(v => `<option value="${v}">${v}</option>`).join('');
    }

    // FILTRATGE DINÀMIC
    function filtrarTaula() {
      const q = document.getElementById('searchInput').value.toLowerCase();
      const d = document.getElementById('filtre-dept').value;
      const c = document.getElementById('filtre-cat').value;
      const disp = document.getElementById('filtre-disp').value;
      const imp = document.getElementById('filtre-imp').value;

      const filtrats = dataset.filter(r => {
        const f = r.fields;
        if (q && !Object.values(f).some(v => String(v).toLowerCase().includes(q))) return false;
        if (d && f.departament !== d) return false;
        if (c && f.categoria !== c) return false;
        if (disp && f.dispositiu !== disp) return false;
        if (imp && f.impacte !== imp) return false;
        return true;
      });

      renderTaula(filtrats);
    }

    function netejarFiltres() {
      document.getElementById('searchInput').value = '';
      document.getElementById('filtre-dept').value = '';
      document.getElementById('filtre-cat').value = '';
      document.getElementById('filtre-disp').value = '';
      document.getElementById('filtre-imp').value = '';
      renderTaula(dataset);
    }

    // RENDER GRAELLA D'INCIDÈNCIES
    function renderTaula(llista) {
      const tbody = document.getElementById('taula-body');
      if (!llista.length) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 40px; color: var(--muted);">Cap incidència coincideix amb la cerca.</td></tr>';
        return;
      }
      // Mostrar primeres 150 files per fluïdesa extrema
      const tall = llista.slice(0, 150);
      tbody.innerHTML = tall.map(r => {
        const f = r.fields;
        const badgeClass = f.impacte.includes('total') ? 'badge-red' : (f.impacte.includes('parcial') ? 'badge-amber' : 'badge-green');
        return `
          <tr onclick="obrirDossier('${encodeURIComponent(JSON.stringify(f))}')">
            <td style="font-family: var(--font-mono); font-size: 11px;">${f.data}</td>
            <td style="font-weight: 600;">${f.nom}</td>
            <td>${f.departament}</td>
            <td>${f.dispositiu}</td>
            <td><span class="badge badge-cyan">${f.equip}</span></td>
            <td>${f.categoria}</td>
            <td><span class="badge ${badgeClass}">${f.impacte.split(':')[0]}</span></td>
          </tr>
        `;
      }).join('');
    }

    // MODAL DOSSIER
    function obrirDossier(jsonStr) {
      const f = JSON.parse(decodeURIComponent(jsonStr));
      const badgeClass = f.impacte.includes('total') ? 'badge-red' : (f.impacte.includes('parcial') ? 'badge-amber' : 'badge-green');

      document.getElementById('modal-content').innerHTML = `
        <div class="dossier-grid">
          <div class="dossier-item"><div class="k">Usuari Afectat</div><div class="v">${f.nom}</div></div>
          <div class="dossier-item"><div class="k">Identificador Equip</div><div class="v"><span class="badge badge-cyan">${f.equip}</span></div></div>
          <div class="dossier-item"><div class="k">Departament</div><div class="v">${f.departament}</div></div>
          <div class="dossier-item"><div class="k">Ubicació / Lloc</div><div class="v">${f.lloc}</div></div>
          <div class="dossier-item"><div class="k">Dispositiu</div><div class="v">${f.dispositiu}</div></div>
          <div class="dossier-item"><div class="k">Data Registre</div><div class="v">${f.data}</div></div>
          <div class="dossier-item"><div class="k">Categoria Principal</div><div class="v">${f.categoria}</div></div>
          <div class="dossier-item"><div class="k">Estat d'Operativitat</div><div class="v"><span class="badge ${badgeClass}">${f.impacte}</span></div></div>
        </div>

        <div>
          <div style="font-size: 11px; font-weight:700; color:var(--muted); text-transform:uppercase; margin-bottom:6px;">Descripció Detallada del Problema</div>
          <div class="problem-box">${f.descripcio}</div>
        </div>
        <div style="font-size: 12px; color: var(--muted);"><strong>Abast:</strong> ${f.abast}</div>
      `;
      document.getElementById('modal').classList.add('open');
    }

    function closeModal() {
      document.getElementById('modal').classList.remove('open');
    }

    // RENDER TELEMETRIA
    function renderTelemetria() {
      dibuixarBars('stats-categoria', 'categoria', '#00f2fe');
      dibuixarBars('stats-impacte', 'impacte', '#ec4899');
      dibuixarBars('stats-dispositiu', 'dispositiu', '#a855f7');
      dibuixarBars('stats-abast', 'abast', '#10b981');
    }

    function dibuixarBars(containerId, field, color) {
      const counts = {};
      dataset.forEach(r => {
        const val = r.fields[field] || 'Sense informar';
        counts[val] = (counts[val] || 0) + 1;
      });
      const sorted = Object.entries(counts).sort((a,b) => b[1] - a[1]);
      const total = dataset.length || 1;

      const html = sorted.map(([k, count]) => {
        const pct = (count / total * 100).toFixed(1);
        return `
          <div class="bar-row">
            <div class="bar-header">
              <span>${k}</span>
              <span style="font-family: var(--font-mono); color: var(--cyan);">${count} (${pct}%)</span>
            </div>
            <div class="bar-track">
              <div class="bar-fill" style="width: ${pct}%; background: ${color};"></div>
            </div>
          </div>
        `;
      }).join('');
      document.getElementById(containerId).innerHTML = html;
    }

    // RENDER DESCARTADES
    function renderDescartades() {
      const tbody = document.getElementById('taula-descartades');
      tbody.innerHTML = rejected.map(r => `
        <tr>
          <td><span class="badge badge-red">#${r.number}</span></td>
          <td style="color: var(--amber); font-weight: 600;">${r.reasons.join(', ')}</td>
          <td>${r.fields.nom || '—'}</td>
          <td style="font-family: var(--font-mono); font-size: 11px;">${r.fields.data || '—'}</td>
          <td style="font-size: 12px; color: var(--muted);">${r.fields.descripcio || '—'}</td>
        </tr>
      `).join('');
    }

    // JSON PREVIEW & EXPORT F4
    async function renderJSONPreview() {
      try {
        const res = await fetch('/api/get_json_preview');
        const text = await res.text();
        document.getElementById('json-viewer').innerText = text;
      } catch (e) {
        document.getElementById('json-viewer').innerText = "// Error llegint incidencies.json";
      }
    }

    async function exportarJSON(mode = 'overwrite') {
      try {
        const res = await fetch('/api/save_json?mode=' + mode, { method: 'POST' });
        const data = await res.json();
        alert(`✔ F4 COMPLETAT!\n\nMode: ${data.accio.toUpperCase()}\nNoves afegides: ${data.afegits}\nDuplicats ignorats: ${data.duplicats_ignorats}\nTotal registres: ${data.total_desats}`);
        renderJSONPreview();
      } catch (e) {
        alert("Error exportant JSON: " + e);
      }
    }

    // CRONÒMETRE F5 (4 MINUTS)
    let timerSec = 4 * 60;
    let timerRunning = false;
    let timerInterval = null;

    function toggleTimer() {
      timerRunning = !timerRunning;
      const btn = document.getElementById('btn-timer');
      if (timerRunning) {
        btn.innerText = '⏸ PAUSAR';
        btn.className = 'btn btn-purple';
        timerInterval = setInterval(() => {
          if (timerSec > 0) {
            timerSec--;
            updateTimerDisplay();
          } else {
            clearInterval(timerInterval);
            timerRunning = false;
            document.getElementById('timer-display').innerText = 'TEMPS!';
            document.getElementById('timer-display').style.color = 'var(--red)';
          }
        }, 1000);
      } else {
        clearInterval(timerInterval);
        btn.innerText = '▶ REPRENDRE';
        btn.className = 'btn btn-cyan';
      }
    }

    function resetTimer() {
      clearInterval(timerInterval);
      timerRunning = false;
      timerSec = 4 * 60;
      updateTimerDisplay();
      document.getElementById('btn-timer').innerText = '▶ INICIAR CRONÒMETRE';
      document.getElementById('btn-timer').className = 'btn btn-cyan';
      document.getElementById('timer-display').style.color = 'var(--green)';
    }

    function updateTimerDisplay() {
      const m = Math.floor(timerSec / 60);
      const s = timerSec % 60;
      document.getElementById('timer-display').innerText = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      if (timerSec <= 30) {
        document.getElementById('timer-display').style.color = 'var(--red)';
      } else if (timerSec <= 60) {
        document.getElementById('timer-display').style.color = 'var(--amber)';
      }
    }
  </script>
</body>
</html>
'''


def processar_fitxer(contingut_text, ordre="mdy"):
    arrel = ET.fromstring(contingut_text)
    if arrel.tag != "incidencies":
        raise ValueError("L'arrel ha de ser <incidencies>.")
    registres = []
    for numero, element in enumerate(arrel, 1):
        if (
            element.tag != "incidencia"
            or len(element) != len(CAMPS)
            or {c.tag for c in element} != set(CAMPS)
        ):
            continue
        registres.append({c.tag: netejar(c.text) for c in element})
    acceptades, descartades = validar_registres(registres, ordre)
    resultat = []
    for fila in acceptades:
        resultat.append({"fields": fila})
    return {
        "total": len(registres),
        "accepted": resultat,
        "rejected": [
            {"number": n, "reasons": m, "fields": registres[n - 1]}
            for n, m in descartades
        ],
    }


class ServidorCinema(BaseHTTPRequestHandler):
    def respondre(self, codi, contingut, tipus):
        self.send_response(codi)
        self.send_header("Content-Type", tipus)
        self.send_header("Content-Length", str(len(contingut)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(contingut)

    def do_GET(self):
        if self.path == "/":
            self.respondre(200, HTML.encode("utf-8"), "text/html; charset=utf-8")
        elif self.path == "/api/data":
            # Autocàrrega de incidencies.xml
            ruta_xml = CARPETA / "incidencies.xml"
            if not ruta_xml.exists():
                ruta_xml = CARPETA / "incidencies_filtrades.xml"
            if ruta_xml.exists():
                with open(ruta_xml, "r", encoding="utf-8", errors="ignore") as f:
                    xml_text = f.read()
                dades = processar_fitxer(xml_text, "mdy")
                self.respondre(
                    200,
                    json.dumps(dades, ensure_ascii=False).encode(),
                    "application/json; charset=utf-8",
                )
            else:
                self.respondre(404, b'{"error":"No s\'ha trobat incidencies.xml"}', "application/json")
        elif self.path == "/api/get_json_preview":
            ruta_json = CARPETA / "incidencies.json"
            if ruta_json.exists():
                with open(ruta_json, "r", encoding="utf-8") as f:
                    text_json = f.read()
                # Mostrem una mostra si és massa gran
                try:
                    obj = json.loads(text_json)
                    mostra = obj[:8] if isinstance(obj, list) else obj
                    res_str = json.dumps(mostra, indent=2, ensure_ascii=False)
                    if isinstance(obj, list) and len(obj) > 8:
                        res_str += f"\n\n// ... i {len(obj) - 8} incidències més en el fitxer incidencies.json."
                    self.respondre(200, res_str.encode("utf-8"), "text/plain; charset=utf-8")
                except Exception:
                    self.respondre(200, text_json[:4000].encode("utf-8"), "text/plain; charset=utf-8")
            else:
                self.respondre(200, b"// El fitxer incidencies.json encara no existeix.\n// Fes clic a Exportar JSON per generar-lo.", "text/plain; charset=utf-8")
        elif self.path == "/api/download_json":
            ruta_json = CARPETA / "incidencies.json"
            if ruta_json.exists():
                with open(ruta_json, "rb") as f:
                    bytes_json = f.read()
                self.respondre(200, bytes_json, "application/json; charset=utf-8")
            else:
                self.respondre(404, b"Fitxer no trobat", "text/plain")
        else:
            self.respondre(404, b"No trobat", "text/plain")

    def do_POST(self):
        if self.path.startswith("/api/save_json"):
            mode = "overwrite"
            if "mode=append" in self.path:
                mode = "append"
            # Carregar dades acceptades del XML i exportar
            ruta_xml = CARPETA / "incidencies.xml"
            if not ruta_xml.exists():
                ruta_xml = CARPETA / "incidencies_filtrades.xml"
            try:
                with open(ruta_xml, "r", encoding="utf-8", errors="ignore") as f:
                    dades = processar_fitxer(f.read(), "mdy")
                acc = [r["fields"] for r in dades["accepted"]]
                res = exportar_json(acc, CARPETA / "incidencies.json", mode=mode)
                self.respondre(200, json.dumps(res, ensure_ascii=False).encode(), "application/json")
            except Exception as e:
                self.respondre(500, json.dumps({"error": str(e)}).encode(), "application/json")
        else:
            self.respondre(404, b"No trobat", "text/plain")

    def log_message(self, *_):
        pass


def main():
    servidor = ThreadingHTTPServer(("127.0.0.1", 0), ServidorCinema)
    servidor.daemon_threads = True
    url = f"http://127.0.0.1:{servidor.server_port}/"
    print(f"\n[CYBER-CORE WEB PRO] Obre al navegador: {url}")
    print("Atura amb Ctrl+C.\n")
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor aturat.")
    finally:
        servidor.server_close()


if __name__ == "__main__":
    main()
